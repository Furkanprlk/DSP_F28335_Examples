//
//      Lab13_2: TMS320F28335
//      (c) Frank Bormann
//
//###########################################################################
//
// FILE:	Lab13_2.c
// 
// TITLE:	DSP28335ControlCARD and stereo audio codec TLV320AIC23
//			to generate two different frequencies at right and left audio channel
//			SPI-A:  control interface for AIC23 @ 1.0MHz Bit Rate
//			McBSP-A: data in (not used) and data out @ 12.0 MHz Bit Rate
//
//			AIC23 generates clock ("BCLK") for McBSP-A (MCLKXA and MCLKRA)
//			BCLK = 12.0 MHz
//			AIC23 generates "LRCIN" as frame sync signal (MFSXA) at 44.1 kHz
//			
//			28335 McBSP-A Transmit Interrupt service to send 64 Bit to AIC23
//			32 Bit left and 32 Bit right channel
//	
//			Signal - Amplitude is generated based on ROM - sine lookup table 
//			
//			variables for signal frequencies "fsine_left", "fsine_right"
//			and "volume" 		
//			Watchdog active, cleared in CPU-Timer0 - ISR and in main-loop 
//			solution file for Lab13_2
//###########################################################################
//  Ver | dd mmm yyyy | Who  | Description of changes
// =====|=============|======|===============================================
//  3.0 | 02 Aug 2009 | F.B. | Lab13_2 for F28335; 
//  3.1 | 22 Nov 2009 | F.B  | Lab13_2 for F28335 @30MHz and PE revision 5
//###########################################################################
#include "DSP2833x_Device.h"
#include "IQmathLib.h"

// external function prototypes
extern void InitSysCtrl(void);
extern void InitPieCtrl(void);
extern void InitPieVectTable(void);
extern void InitCpuTimers(void);
extern void ConfigCpuTimer(struct CPUTIMER_VARS *, float, float);


// Prototype statements for functions found within this file.
void Gpio_select(void);
void SPIA_Init(void);
void McBSPA_Init(void);
void AIC23_init(void);
interrupt void cpu_timer0_isr(void);
interrupt void McBSP_A_TX_isr(void);

// Global Variables
#pragma DATA_SECTION(sine_table,"IQmathTables");
_iq30 sine_table[512];	// lookup-table 512 values in I2Q30 (+1...-1)
float volume = 0.2;				// relative sound volume control (0...1) 
unsigned int fsine_left= 110; 	// left audio sine frequency in Hertz
unsigned int fsine_right = 220;	// right audio sine frequency in Hertz

//###########################################################################
//						main code									
//###########################################################################
void main(void)
{
	InitSysCtrl();	// SYSCLK = 150 MHz, HSPCLK = 75 MHz,
					// LSPCLK = 37.5 MHz
					// all peripherals enabled
					// watchdog disabled
	EALLOW;
   	SysCtrlRegs.WDCR= 0x00AF;	// Re-enable the watchdog, Prescaler = 64 
   	EDIS;			

	Gpio_select();		// GPIO9, GPIO11, GPIO34 and GPIO49 as output
						// to 4 LEDs at Peripheral Explorer	

	SPIA_Init();		// init SPI-A as control channel for AIC23

	McBSPA_Init();		// init McBSP-A as data channel for AIC23

	AIC23_init();		// send initialize commands to AIC23

	InitPieCtrl();		// basic setup of PIE table; from DSP2833x_PieCtrl.c
	
	InitPieVectTable();	// default ISR's in PIE

	EALLOW;
	PieVectTable.TINT0 = &cpu_timer0_isr;
	PieVectTable.MXINTA = &McBSP_A_TX_isr;
	EDIS;

	InitCpuTimers();	// basic setup CPU Timer0, 1 and 2

	ConfigCpuTimer(&CpuTimer0,150,100000);
	// Enable CPU - Timer0 - INT in PIE: Group 1 interrupt 7
	PieCtrlRegs.PIEIER1.bit.INTx7 = 1;
	// Enable McBSP-A MXINTA-INT in PIE: Group 6 interrupt 6
   	PieCtrlRegs.PIEIER6.bit.INTx6 = 1;

	IER |=0x21;			// INT1 and INT6 enabled

	EINT;
	ERTM;

	CpuTimer0Regs.TCR.bit.TSS = 0;	// start timer0

	while(1)
	{    
	  		while(CpuTimer0.InterruptCount == 0);
			CpuTimer0.InterruptCount = 0;
			
			EALLOW;
			SysCtrlRegs.WDKEY = 0x55;	// service WD #1
			EDIS;

	  		GpioDataRegs.GPBTOGGLE.bit.GPIO34 = 1;		// toggle red LED LD3 @ 28335CC
	}
} 

void Gpio_select(void)
{
	EALLOW;
	GpioCtrlRegs.GPAMUX1.all = 0;		// GPIO15 ... GPIO0 = General Puropse I/O
	GpioCtrlRegs.GPAMUX2.all = 0;		// GPIO31 ... GPIO16 = General Purpose I/O
	GpioCtrlRegs.GPBMUX1.all = 0;		// GPIO47 ... GPIO32 = General Purpose I/O
	GpioCtrlRegs.GPBMUX2.all = 0;		// GPIO63 ... GPIO48 = General Purpose I/O
	GpioCtrlRegs.GPCMUX1.all = 0;		// GPIO79 ... GPIO64 = General Purpose I/O
	GpioCtrlRegs.GPCMUX2.all = 0;		// GPIO87 ... GPIO80 = General Purpose I/O

	GpioCtrlRegs.GPAMUX2.bit.GPIO16 = 1;	// SPI-A SPISIMO for AIC23 "SDIN"
	GpioCtrlRegs.GPAMUX2.bit.GPIO18 = 1;	// SPI-A SPICLK  for AIC23 "SCLK"
	GpioCtrlRegs.GPAMUX2.bit.GPIO19 = 1;	// SPI-A SPISTE  for AIC23 "/CS"

	GpioCtrlRegs.GPAMUX2.bit.GPIO20 = 2;	// McBSP-A MDXA  for AIC23 "DIN"
	GpioCtrlRegs.GPAQSEL2.bit.GPIO20 = 3;	// Asynch only
	GpioCtrlRegs.GPAMUX2.bit.GPIO21 = 2;	// McBSP-A MDRA  for AIC23 "DOUT"
	GpioCtrlRegs.GPAQSEL2.bit.GPIO21 = 3;	// Asynch only
	GpioCtrlRegs.GPAMUX2.bit.GPIO22 = 2;	// McBSP-A MCLKXA for AIC23 "BCLK"
	GpioCtrlRegs.GPAQSEL2.bit.GPIO22 = 3;	// Asynch only
	GpioCtrlRegs.GPAMUX2.bit.GPIO23 = 2;	// McBSP-A MFSXA for AIC23 "LRCIN"
	GpioCtrlRegs.GPAQSEL2.bit.GPIO23 = 3;	// Asynch only
	GpioCtrlRegs.GPBMUX2.bit.GPIO58 = 1;	// McBSP-A MCLKRA for AIC23 "BCLK"
	GpioCtrlRegs.GPBMUX2.bit.GPIO59 = 1;	// McBSP-A MFSRA for AIC23 "LRCOUT"
	 
	GpioCtrlRegs.GPADIR.all = 0;
	GpioCtrlRegs.GPADIR.bit.GPIO9 = 1;	// peripheral explorer: LED LD1 at GPIO9
	GpioCtrlRegs.GPADIR.bit.GPIO11 = 1;	// peripheral explorer: LED LD2 at GPIO11

	GpioCtrlRegs.GPBDIR.all = 0;		// GPIO63-32 as inputs
	GpioCtrlRegs.GPBDIR.bit.GPIO34 = 1;		// peripheral explorer: LED LD3 at GPIO34
	GpioCtrlRegs.GPBDIR.bit.GPIO49 = 1; 	// peripheral explorer: LED LD4 at GPIO49
	
	GpioCtrlRegs.GPCDIR.all = 0;		// GPIO87-64 as inputs
	EDIS;
}  

//==============================================
// 					SPI-A Setup
// Control Channel for AIC23 audio codec
//============================================== 
void SPIA_Init(void)
{	
	SpiaRegs.SPICCR.bit.SPISWRESET = 0;		// Hold SPI in reset
	SpiaRegs.SPICCR.bit.SPICHAR = 15;		// 16 bit char
	SpiaRegs.SPICCR.bit.CLKPOLARITY = 1;	// Output on falling edge
	SpiaRegs.SPICCR.bit.SPILBK = 0;			// No Loopback
	SpiaRegs.SPICCR.bit.SPISWRESET = 1;		// Release SPI from reset  
	
	SpiaRegs.SPIBRR = 37;
	// SPI Bit Rate =  LSPCLK / ( SPIBRR + 1)
	//			    =  37.5 MHz / ( 37 + 1 )
	//			    =  0.99 MHz

	SpiaRegs.SPICTL.bit.MASTER_SLAVE = 1;	// Master mode
	SpiaRegs.SPICTL.bit.CLK_PHASE = 0;		// No Delay
	SpiaRegs.SPICTL.bit.OVERRUNINTENA = 0;	// Disable
	SpiaRegs.SPICTL.bit.TALK = 1;			// Enable TX
	SpiaRegs.SPICTL.bit.SPIINTENA = 0;		// Disable Interrupt Request
}

//==============================================
// 					McBSP-A Setup
//  			Data channel for AIC23
//==============================================
void McBSPA_Init()
{   	
    EALLOW;
   	McbspaRegs.SPCR1.all=0x0000;		// Reset Receiver

	McbspaRegs.SPCR2.all=0x0000;		// Reset FS generator, sample rate generator & transmitter
 	McbspaRegs.SPCR2.bit.FREE  = 1;		// Free run in break event 
	McbspaRegs.SPCR2.bit.XINTM = 2;		// Transmit - Interrupt on every MFSXA
	McbspaRegs.SPCR2.bit.XRST = 1;		// Release Transmitter from Reset
	McbspaRegs.SPCR2.bit.FRST = 1;		// Frame sync generator pulled out of reset
	McbspaRegs.SPCR2.bit.GRST = 1;		// Ssample rate generator pulled out of reset
 	
 	McbspaRegs.MFFINT.bit.RINT = 0;		// Receive INT on RRDY is disabled
	McbspaRegs.MFFINT.bit.XINT = 1;		// Transmit INT on XRDY is enabled

    McbspaRegs.XCR1.all=0x0;
	McbspaRegs.XCR1.bit.XWDLEN1 = 5;	// 32 bit data in phase 1 
    McbspaRegs.XCR1.bit.XFRLEN1 = 0;	// Xmit frame length = 1 word in phase1 for left channel
    
    McbspaRegs.XCR2.all=0x0;			// No companding	(Transmit)
    McbspaRegs.XCR2.bit.XPHASE = 1;		// Dual-phase frame
    McbspaRegs.XCR2.bit.XWDLEN2 = 5;	// 32 bit data in phase 2 
    McbspaRegs.XCR2.bit.XFRLEN2 = 0;	// Xmit frame length = 1 word in phase2 for right channel
	McbspaRegs.XCR2.bit.XDATDLY = 1;    // If LRP (AIC23) = 0, X/RDATDLY=0, if LRP=1, X/RDATDLY=1  
    
	McbspaRegs.SRGR2.bit.CLKSM = 1;		// pin MCLKX is clock source for SRG
	
    McbspaRegs.PCR.all=0x0000;			// Frame sync generated externally, CLKX/CLKR driven
    McbspaRegs.PCR.bit.FSXM = 0;		// FSX is always an input signal
	McbspaRegs.PCR.bit.FSRM = 0;		// FSR is always an input signal
	McbspaRegs.PCR.bit.SCLKME = 1;		// pin MCLKX is clock source for SRG
    McbspaRegs.PCR.bit.FSRP = 0;		// 1-FSRP is active low 0-FSRP is active high
	McbspaRegs.PCR.bit.FSXP = 0;        // 0-FSXP is active low
    McbspaRegs.PCR.bit.CLKRP  = 1;		// 1-Rcvd data sampled on rising edge of CLKR
	McbspaRegs.PCR.bit.CLKXP  = 0;      // 0- data transmitted on rising  edge of CLKX
	McbspaRegs.PCR.bit.CLKXM = 0;		// 0-MCLKXA is an input driven by an external clock
    McbspaRegs.PCR.bit.CLKRM = 0;		// MCLKRA is an input signal

    EDIS;
}

//==============================================
// 				AIC23 Codec Setup
//==============================================
void AIC23_init(void)
{
    volatile unsigned int i;
    // Reset AIC23
   	SpiaRegs.SPITXBUF = 0x1E00;
	while (SpiaRegs.SPISTS.bit.INT_FLAG != 1);	// Wait until character has been transferred
	i = SpiaRegs.SPIRXBUF;						// dummy read clears INT_FLAG
    // Power down: In/Out/DAC/ADC/Mic
    // Leave AIC23 device and oscillatorclks on		 
    SpiaRegs.SPITXBUF = 0x0C1F;
	while (SpiaRegs.SPISTS.bit.INT_FLAG != 1);
	i = SpiaRegs.SPIRXBUF;	
    // Left headphone volume control 
	// 0x0079 = 0dB (default)
	SpiaRegs.SPITXBUF = 0x04F9;
	while (SpiaRegs.SPISTS.bit.INT_FLAG != 1);	
	i = SpiaRegs.SPIRXBUF;
    // Right headphone volume control
	// 0x0079 = 0dB (default)
	SpiaRegs.SPITXBUF = 0x06F9;
	while (SpiaRegs.SPISTS.bit.INT_FLAG != 1);	
	i = SpiaRegs.SPIRXBUF;
	// Turn on DAC, mute mic
	SpiaRegs.SPITXBUF = 0x0812;
	while (SpiaRegs.SPISTS.bit.INT_FLAG != 1);
	i = SpiaRegs.SPIRXBUF;
	// Disable DAC mute
	SpiaRegs.SPITXBUF = 0x0A00;
	while (SpiaRegs.SPISTS.bit.INT_FLAG != 1);
	i = SpiaRegs.SPIRXBUF;
	// AIC23 master mode, DSP mode,32-bit data, LRP=1 to match with XDATADLY=1
	SpiaRegs.SPITXBUF = 0x0E5F;
	while (SpiaRegs.SPISTS.bit.INT_FLAG != 1);
	i = SpiaRegs.SPIRXBUF;
	// 12 MHz USB clock - 44.1 MHz sample rate in USB mode
	SpiaRegs.SPITXBUF = 0x1023;
	while (SpiaRegs.SPISTS.bit.INT_FLAG != 1);
	i = SpiaRegs.SPIRXBUF;
	// Activate digital interface
	SpiaRegs.SPITXBUF = 0x1201;
	while (SpiaRegs.SPISTS.bit.INT_FLAG != 1);
	i = SpiaRegs.SPIRXBUF;
	// Turn everything on except Mic.
	SpiaRegs.SPITXBUF = 0x0C02;
	while (SpiaRegs.SPISTS.bit.INT_FLAG != 1);
	i = SpiaRegs.SPIRXBUF;
}

interrupt void cpu_timer0_isr(void)
{
	CpuTimer0.InterruptCount++;
	EALLOW;
	SysCtrlRegs.WDKEY = 0xAA;	// service WD #2
	EDIS;
	// Acknowledge PIE-Group 1
	PieCtrlRegs.PIEACK.bit.ACK1 = 1;
}

//==============================================
// McBSP-A TX interrupt service function
//==============================================
// ISR runs every 1/44.1KHz = 22.675�s
// and is triggered by AIC23 LRCIN = MFSXA
interrupt void McBSP_A_TX_isr(void)
{
	static unsigned int left_linear_idx=0, right_linear_idx;
	unsigned int left_lut_idx,right_lut_idx;
	long left_amplitude,right_amplitude;  
      	
   	left_lut_idx = ((left_linear_idx*(long)fsine_left*512)/44100);
	if(left_lut_idx>511) 
	{
		left_linear_idx=0;
		left_lut_idx = 0;
	}
	// amplitude in I2Q30 = sin(x) * volume(0...1)
	left_amplitude = _IQ30mpy(sine_table[left_lut_idx],_IQ30(volume));
	// amplitude from I2Q30 into I1Q31
	left_amplitude <<= 1;

	right_lut_idx = ((right_linear_idx*(long)fsine_right*512)/44100);
	if(right_lut_idx>511) 
	{
		right_linear_idx=0;
		right_lut_idx = 0;
	}
	// amplitude in I2Q30 = sin(x) * volume(0...1)
	right_amplitude = _IQ30mpy(sine_table[right_lut_idx],_IQ30(volume));
	// amplitude from I2Q30 into I1Q31
	right_amplitude <<= 1;

	McbspaRegs.DXR2.all = left_amplitude >> 16;			// high 16 Bit 
	McbspaRegs.DXR1.all = left_amplitude & 0x0000FFFF;	// low 16 Bit
	while(McbspaRegs.SPCR2.bit.XRDY == 0);		// poll for end of phase1
				// note: not best practice to poll inside of an ISR !!!
	McbspaRegs.DXR2.all = right_amplitude >> 16;			// high 16 Bit
	McbspaRegs.DXR1.all = right_amplitude & 0x0000FFFF;	// low 16 Bit 

    left_linear_idx +=1;          // use next element out of lookup table
    if (left_linear_idx >511) left_linear_idx = 0; 
   
   	right_linear_idx +=1;          // use next element out of lookup table
    if (right_linear_idx >511) right_linear_idx = 0; 
	// Acknowledge interrupt to receive more interrupts from group 6
   	PieCtrlRegs.PIEACK.bit.ACK6 = 1;
}
//===========================================================================
// End of SourceCode.
//===========================================================================
