#ifdef __cplusplus
#pragma DATA_SECTION("myFlashConstants")
#else
#pragma DATA_SECTION(FLASH_Voltage_A0,"myFlashConstants");
#endif
volatile unsigned int FLASH_Voltage_A0;
