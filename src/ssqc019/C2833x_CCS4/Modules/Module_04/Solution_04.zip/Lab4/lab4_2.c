unsigned int i;
float k;
float f = 1.0;

void main(void)
{
	while(1)
	{
		for (i=0; i<100; i++)
		{
			k = f*f;
			f = f + 1.0;	
		}
	}
}
