unsigned int k;
unsigned int i;

void main(void)
{
	while(1)
	{
		for (i=0; i<100; i++)
		{
			k = i*i;
		}
	}
}
