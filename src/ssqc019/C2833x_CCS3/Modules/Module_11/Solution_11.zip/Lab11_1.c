//
//      Lab11_1: TMS320F28335
//      (c) Frank Bormann
//
//###########################################################################
//
// FILE:	Lab11_1.c
// 
// TITLE:	CAN - Transmit via F28335controlCARD 
//			and SH65HVD230 at Peripheral Explorer Board
//
//			Extended CAN-Frame transmit at 100 kbit/s
//
//			Objective:
//			Transmit an incremental 8-Bit -Pattern  
//			repeat the transmission at 1.0 seconds intervals
//			Mailbox 5 is transmit mailbox in use
//			Identifier : 0x1000 0000 
//			Data Length Code DLC =  1
// 
//			physical eCAN is at GPIO31 (CANTXA) and GPIO30 (CANRXA)
//
// 			Frequency Osscillator @F28335controlCARD: 30MHz
// 			PLLCR = 10   :  multiply by 5  
//			SYSCLKOUT = 150MHz , 28335-CAN-CLKIN = 75MHz
//###########################################################################
//  Ver | dd mmm yyyy | Who  | Description of changes
// =====|=============|======|===============================================
//  3.0 | 14 Jul 2009 | F.B. | solution file Lab11_1 for F28335; 
//  3.1 | 15 Nov 2009 | F.B  | Lab11_1 for F28335 @30MHz and PE revision 5
//###########################################################################
#include "DSP2833x_Device.h"

// external function prototypes
extern void InitSysCtrl(void);
extern void InitPieCtrl(void);
extern void InitPieVectTable(void);
extern void InitCpuTimers(void);
extern void InitECan(void);	
extern void ConfigCpuTimer(struct CPUTIMER_VARS *, float, float);


// Prototype statements for functions found within this file.
void Gpio_select(void);
interrupt void cpu_timer0_isr(void);

//###########################################################################
//						main code									
//###########################################################################
void main(void)
{
	int counter=0;	// binary counter for digital output
	struct	ECAN_REGS ECanaShadow;		// local copy of CANA registers

	InitSysCtrl();	// Basic Core Initialization
					// SYSCLK=150MHz, HISPCLK=75MHz, LSPCLK=37.5MHz

	EALLOW;
   	SysCtrlRegs.WDCR= 0x00AF;	// Re-enable the watchdog 
   	EDIS;			// 0x00AF  to NOT disable the Watchdog, Prescaler = 64

	DINT;				// Disable all interrupts
	
	Gpio_select();	// GPIO9, GPIO11, GPIO34 and GPIO49 as output
					// to 4 LEDs at Peripheral Explorer	

	/* Initialize the CAN module */
	// NOTE: first modify TI-file: InitECan() to 100kbps by setting BTR = 49
	InitECan();	
	
	/* Write to Mailbox 5 message ID field  */
    ECanaMboxes.MBOX5.MSGID.all     = 0x10000000;	// message identifier 
    ECanaMboxes.MBOX5.MSGID.bit.IDE = 1;  // Extended Identifier
       
	/* Configure Mailbox 5 as transmit mailbox */
	ECanaShadow.CANMD.all = ECanaRegs.CANMD.all;	
	ECanaShadow.CANMD.bit.MD5 = 0;
	ECanaRegs.CANMD.all = ECanaShadow.CANMD.all; 
	
	/* Enable Mailbox 5  */
	ECanaShadow.CANME.all = ECanaRegs.CANME.all;	
	ECanaShadow.CANME.bit.ME5 = 1;
	ECanaRegs.CANME.all = ECanaShadow.CANME.all; 

	/* Write to DLC field in Master Control reg */
	ECanaMboxes.MBOX5.MSGCTRL.all = 0;
	ECanaMboxes.MBOX5.MSGCTRL.bit.DLC = 1;

	InitPieCtrl();		// basic setup of PIE table; from DSP2833x_PieCtrl.c
	
	InitPieVectTable();	// default ISR's in PIE

	EALLOW;
	PieVectTable.TINT0 = &cpu_timer0_isr;
	EDIS;

	InitCpuTimers();	// basic setup CPU Timer0, 1 and 2

	ConfigCpuTimer(&CpuTimer0,150,100000);

	PieCtrlRegs.PIEIER1.bit.INTx7 = 1;

	IER |=1;

	EINT;
	ERTM;

	CpuTimer0Regs.TCR.bit.TSS = 0;	// start timer0

	while(1)
	{    
	  		while(CpuTimer0.InterruptCount < 10)	// wait for 10*100 milliseconds
			{
				EALLOW;
				SysCtrlRegs.WDKEY = 0xAA;	// service WD #2
				EDIS;
			}
			CpuTimer0.InterruptCount = 0;

			ECanaMboxes.MBOX5.MDL.byte.BYTE0 = counter & 0x00FF ;
     		ECanaShadow.CANTRS.all = 0; 	
     		ECanaShadow.CANTRS.bit.TRS5 = 1;     // Set TRS for mailbox under test       
     		ECanaRegs.CANTRS.all = ECanaShadow.CANTRS.all; 

			while(ECanaRegs.CANTA.bit.TA5 == 0 ) // Wait for TA5 bit to be set.
     		{
				EALLOW;
				SysCtrlRegs.WDKEY = 0xAA;				// Service watchdog #2
				EDIS;
     		} 
			   
	     	ECanaShadow.CANTA.all = 0; 	
	     	ECanaShadow.CANTA.bit.TA5 = 1;     	 // Clear Transmit Acknowledge #5       
	     	ECanaRegs.CANTA.all = ECanaShadow.CANTA.all;
			
			counter++;
			GpioDataRegs.GPBTOGGLE.bit.GPIO34 = 1;		// toggle red LED LD3 @ 28335CC
	}
} 

void Gpio_select(void)
{
	EALLOW;
	GpioCtrlRegs.GPAMUX1.all = 0;		// GPIO15 ... GPIO0 = General Puropse I/O
	GpioCtrlRegs.GPAMUX2.all = 0;		// GPIO31 ... GPIO16 = General Purpose I/O
	
	GpioCtrlRegs.GPAMUX2.bit.GPIO30 = 1;	// CANA_RX
	GpioCtrlRegs.GPAMUX2.bit.GPIO31 = 1;	// CANA_TX

	GpioCtrlRegs.GPBMUX1.all = 0;		// GPIO47 ... GPIO32 = General Purpose I/O
	GpioCtrlRegs.GPBMUX2.all = 0;		// GPIO63 ... GPIO48 = General Purpose I/O
	GpioCtrlRegs.GPCMUX1.all = 0;		// GPIO79 ... GPIO64 = General Purpose I/O
	GpioCtrlRegs.GPCMUX2.all = 0;		// GPIO87 ... GPIO80 = General Purpose I/O
	 
	GpioCtrlRegs.GPADIR.all = 0;
	GpioCtrlRegs.GPADIR.bit.GPIO9 = 1;	// peripheral explorer: LED LD1 at GPIO9
	GpioCtrlRegs.GPADIR.bit.GPIO11 = 1;	// peripheral explorer: LED LD2 at GPIO11

	GpioCtrlRegs.GPBDIR.all = 0;		// GPIO63-32 as inputs
	GpioCtrlRegs.GPBDIR.bit.GPIO34 = 1;	// peripheral explorer: LED LD3 at GPIO34
	GpioCtrlRegs.GPBDIR.bit.GPIO49 = 1; // peripheral explorer: LED LD4 at GPIO49

	GpioCtrlRegs.GPCDIR.all = 0;		// GPIO87-64 as inputs
	EDIS;
}   

interrupt void cpu_timer0_isr(void)
{
	CpuTimer0.InterruptCount++;
	EALLOW;
	SysCtrlRegs.WDKEY = 0x55;	// service WD #1
	EDIS;
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}
//===========================================================================
// End of SourceCode.
//===========================================================================
