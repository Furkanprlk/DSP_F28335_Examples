//================================================================================
//	ADC_CascSeqCNF(int ChSel[], int ACQPS, int NumConvSEQ1, int mode)
//================================================================================
//	FILE:			ADC_CascSeqCnf.C
//
//	Description:	ADC configuration to support up to 16 conversions in Cascaded mode
//					Functions allows Channel selections and S/H acquisition window
//					width programming.
//
//	Version: 		1.00
//
//  Target:  		TMS320F280xx
//
//----------------------------------------------------------------------------------
//  Copyright Texas Instruments � 2007
//----------------------------------------------------------------------------------
//  Revision History:
//----------------------------------------------------------------------------------
//  Date	  | Description
//----------------------------------------------------------------------------------
//  08/30/07  | Release 1.0  		New release.
//----------------------------------------------------------------------------------
#include "PeripheralHeaderIncludes.h"	// Include all Peripheral Headers

//================================================================================
//			_______________________
//			|	  ADC???_DRV	   |
//			|~~~~~~~~~~~~~~~~~~~~~~|
//		 <--| Rslt[0~15]   ADC-A0  |<--
//		 	|		  	   ADC-A1  |<--
//		 	|		  	      "    |<--
//		 	|		  	   ADC-A7  |<--
//		 	|		  	    	   |<--
//	ChSel-->|		  	   ADC-B0  |<--
//		 	|		  	      "    |<--
//		 	|		  	   ADC-B7  |<--
//			|______________________|
//
// Description:
// ------------
// ADC peripheral Driver Configuration for a Cascaded Sequencer conversion session
// ChSel[] = Channel selection made via a channel # array passed as an argument
// NumConvSEQ1 = number of conversions in a session or wrap-around of state pointer
// ACQPS = AcqWidth is the S/H aperture in #ADCCLKS, i.e.
// 							AcqWidth = 1 gives = 1 ADCCLK
// 							AcqWidth = 2 gives = 2 ADCCLK
// 							AcqWidth = 3 gives = 3 ADCCLK....etc
//							Note: valid values are 1-16
// Mode = Operating mode: 	0 = Start / Stop mode, needs SOCA trigger event
//							1 = Continuous mode, no trigger needed
//============================================================================
void ADC_CascSeqCNF(int ChSel[], int ACQPS, int NumConvSEQ1, int mode)
{

// ADC power-up sequence		
	AdcRegs.ADCTRL3.bit.ADCBGRFDN = 0x3;	// Power up bandgap/reference circuitry
	AdcRegs.ADCTRL3.bit.ADCPWDN = 0x1;		// Power up rest of ADC

// ADC Acquisition window select and Channel allocation
	AdcRegs.ADCTRL3.bit.ADCCLKPS=0;			// ADCCLK=12.5 MHz @ HSCLK=25MHz
	AdcRegs.ADCTRL1.bit.ACQ_PS= ACQPS; 		// Window aperture

// ADC Sequencer and Interrupt Init
    AdcRegs.ADCTRL1.bit.SEQ_CASC = 1;		// Single 16 state sequencer
    AdcRegs.ADCTRL1.bit.SEQ_OVRD = 0;		// Wrap at MaxConv

// # of Conversions & Input channel Allocation
    AdcRegs.ADCMAXCONV.all = (NumConvSEQ1-1);		// Number of conversions

	AdcRegs.ADCCHSELSEQ1.bit.CONV00=ChSel[0];		// 1st conv - Sequencer 1
	AdcRegs.ADCCHSELSEQ1.bit.CONV01=ChSel[1];		// 2nd conv - Sequencer 1
	AdcRegs.ADCCHSELSEQ1.bit.CONV02=ChSel[2];		// 3rd conv - Sequencer 1
	AdcRegs.ADCCHSELSEQ1.bit.CONV03=ChSel[3];		// 4th conv - Sequencer 1
	AdcRegs.ADCCHSELSEQ2.bit.CONV04=ChSel[4];		// 5th conv - Sequencer 1
	AdcRegs.ADCCHSELSEQ2.bit.CONV05=ChSel[5];		// 6th conv - Sequencer 1
	AdcRegs.ADCCHSELSEQ2.bit.CONV06=ChSel[6];		// 7th conv - Sequencer 1
	AdcRegs.ADCCHSELSEQ2.bit.CONV07=ChSel[7];		// 8th conv - Sequencer 1

	AdcRegs.ADCCHSELSEQ3.bit.CONV08=ChSel[8];		// 9th conv - Sequencer  1
	AdcRegs.ADCCHSELSEQ3.bit.CONV09=ChSel[9];		// 10th conv - Sequencer 1
	AdcRegs.ADCCHSELSEQ3.bit.CONV10=ChSel[10];		// 11th conv - Sequencer 1
	AdcRegs.ADCCHSELSEQ3.bit.CONV11=ChSel[11];		// 12th conv - Sequencer 1
	AdcRegs.ADCCHSELSEQ4.bit.CONV12=ChSel[12];		// 13th conv - Sequencer 1
	AdcRegs.ADCCHSELSEQ4.bit.CONV13=ChSel[13];		// 14th conv - Sequencer 1
	AdcRegs.ADCCHSELSEQ4.bit.CONV14=ChSel[14];		// 15th conv - Sequencer 1
	AdcRegs.ADCCHSELSEQ4.bit.CONV15=ChSel[15];		// 16th conv - Sequencer 1

	if (mode==0)
    {
    	AdcRegs.ADCTRL1.bit.CONT_RUN = 0;		// Start-Stop Conv mode
    	AdcRegs.ADCTRL2.bit.EPWM_SOCA_SEQ1 = 1;	// Start Conv via ePWM SOCA trigger event
	}
	if (mode==1)
    {
    	AdcRegs.ADCTRL1.bit.CONT_RUN = 1;		// Continuous Conv mode
    	AdcRegs.ADCTRL2.bit.SOC_SEQ1 = 1;		// Kick-start the ADC now
	}
}





