//----------------------------------------------------------------------------------
//	FILE:			TwoChannel-Main.C
//
//	Description:	2 Output DC/DC closed loop control system, with ADC
//					s/w drivers, and a 2-pole/2-zero compensation/control law.
//
//	Version: 		1.0
//
//  Target:  		TMS320F280xx
//
//----------------------------------------------------------------------------------
//  Copyright Texas Instruments � 2007
//----------------------------------------------------------------------------------
//  Revision History:
//----------------------------------------------------------------------------------
//  Date	  | Description / Status
//----------------------------------------------------------------------------------
// 29 Aug-07  | Release 1.0  		2 Channel Internal release (DAF)
//----------------------------------------------------------------------------------
#include "PeripheralHeaderIncludes.h"	// Include all Peripheral Headers
#include "DSP280x_EPWM_defines.h" 		// useful defines specific to EPWM
//#include "SFO.h"

//===============================================================
// Incremental Build options for System check-out
//---------------------------------------------------------------
// Notes: 
// o  make sure same conditional assembly option is chosen in
//    the corresponding .asm file
// o  choose only one option at a time, and re-build before running
//---------------------------------------------------------------
#define	IB1		1	// Open loop - Channels 1,2
#define	IB2		0	// Closed loop - Ch1 only using separate lib blocks

// System Defines
//---------------------------------------------------------------
#define	NumChannels	2	// Number of Channels supported by Hardware
#define	DMAX1	500		// Clamping value for normal operation = 50%


// System specific function prototypes
//---------------------------------------------------------------
void DeviceInit(void);
void ISR_Init(void);
void ISR_Run(void);
void BuckSingle_CNF(int n, int prd, int mode, int phase);
void ADC_CascSeqCNF(int ChSel[], int ACQPS, int Conv, int mode);
void ADC_DualSeqCNF(int ChSel[], int ACQPS, int Conv, int mode);


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// State Machine function prototypes and related stuff
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// Alpha states
void A0(void);	//state A0
void B0(void);	//state B0
void C0(void);	//state C0

// A branch states
void A1(void);	//state A1
void A2(void);	//state A2
void A3(void);	//state A3
void A4(void);	//state A4

// B branch states
void B1(void);	//state B1
void B2(void);	//state B2
void B3(void);	//state B3
void B4(void);	//state B4

// C branch states
void C1(void);	//state C1
void C2(void);	//state C2
void C3(void);	//state C3
void C4(void);	//state C4

// Variable declarations
void (*Alpha_State_Ptr)(void);	// Base States pointer
void (*A_Task_Ptr)(void);		// State pointer A branch
void (*B_Task_Ptr)(void);		// State pointer B branch
void (*C_Task_Ptr)(void);		// State pointer C branch

//===============================================================
// State Machine Sync timers period definition @ 100 MHz sysclk
//---------------------------------------------------------------
#define		T0PERIOD	100000	// 1000 uS (1.000 mS) - A tasks
#define		T1PERIOD	400000	// 4000 uS (4.000 mS) - B tasks
#define		T2PERIOD	800000	// 8000 uS (8.000 mS) - C tasks

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// Variable Declarations
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// General System nets & parameters
int16	i;
int16	ZeroNet, BlackHoleNet;
int16	AdcNetBus[NumChannels+1]; 	// used as consecutive addresses for ADC_Rslts
int16	VrefNetBus[NumChannels+1]; 	// used as consecutive addresses for Vref
int16	UoutNetBus[NumChannels+1]; 	// used as consecutive addresses for Uout
int16	Vref, Uout, Vfdbk;
int16	VTimer01, VTimer02, VTimer03; // Virtual Timers slaved of CPU Timer 0
int16	VTimer11, VTimer12, VTimer13; // Virtual Timers slaved of CPU Timer 1
int16	VTimer21, VTimer22, VTimer23; // Virtual Timers slaved of CPU Timer 2
int16 	MEP_ScaleFactor[5];
long	Coef2P2Z[7], Coef2P2Z_1[7], Coef2P2Z_2[7];
long	DataLogTrigger;

// Soft Start & Sequencing Control
Uint16	StartUpAll, FastShutDownAll, HRmode;
Uint16	SoftStartStatePtr, BlinkStatePtr;
Uint16	LoadDrvCtr, LoadDrvPtr;
Uint16	TempChSel, LED_TaskPtr;

int16	Vtarget[NumChannels+1], Dmax[NumChannels+1];
int16	DelayCtr, ChannelCtr, SlewError, Vtrgt, SlewStepG, Duty;
int16	Duty1, Duty2;
int16	tADCSOS;
int		ChSel[16];

// Used to indirectly access all EPWM modules, very useful!
volatile struct EPWM_REGS *ePWM[] = 
 				  { &EPwm1Regs,
					&EPwm1Regs,				  
					&EPwm2Regs,
					&EPwm3Regs,
					&EPwm4Regs,
					&EPwm5Regs,
					&EPwm6Regs,
//					&EPwm7Regs,
//					&EPwm8Regs,
//					&EPwm9Regs,
//					&EPwm10Regs
					};

// User / GUI control
// ------------------------------------------------------------
int16	ChannelEnable[NumChannels+1], Vsoft[NumChannels+1];
int16	Vout[NumChannels+1], SlewStep[NumChannels+1], Vmargin[NumChannels+1];
int16	StartUp, StopAll, CommsOKflg, VTimer01;
int16	OnDelay[NumChannels+1], OffDelay[NumChannels+1];
int16	Pgain, Igain, Dgain;
Uint16	ActiveLoad, LED_Data;
int16	ScopeGain, ScopeDcOffset, ScopeACmode;

// Dashboard
int16	BCptr, TempBCptr, Scratch, LedOn[9], LedOff[9];
int16	VinH[8];							// History (H) Array for Vin meas.
int16	VoutH1[8], VoutH2[8];				// History (H) Array for Vout meas.
int16	IoutH1[8], IoutH2[8];				// History (H) Array for Iout meas.
int16	DegCH1[8], DegCH2[8];				// History (H) Array for Temp meas.
long	TdegC[NumChannels+1], Vmeas[NumChannels+1], Imeas[NumChannels+1];
long	VinMeas;
long	Tzero, Izero, Kt, Kv, Ki, Kvi, Dmy1;

// Used for running BackGround in flash, and ISR in RAM
extern int16 *RamfuncsLoadStart, *RamfuncsLoadEnd, *RamfuncsRunStart;

//===========================================================================
// ASM Module Terminal pointers and Variables
//===========================================================================
extern int16	*Buck_In1, *Buck_In2, *Buck_In3, *Buck_In4;
extern int16	*ADC_Rslt, *CNTL_2P2Z_Ref1, *CNTL_2P2Z_Out1, *CNTL_2P2Z_Fdbk1;
extern int16	*Buck_Ref, *Buck_Out;
extern long		*Buck_CoefPtr1, *Buck_CoefPtr2, *CNTL_2P2Z_Coef1;
extern int16	SFBUCK1n, SFBUCK2n;

// Data Logging
extern int		*DLTST_In1, *DLTST_In2;
extern int		DLTST_DcOffset1, DLTST_DcOffset2;
extern int		DLTST_Gain1, DLTST_Gain2;
extern long		*DLTST_TimeStampTrig1, *DLTST_TimeStampTrig2;
extern volatile Uint32	*DLTST_TimeBase1, *DLTST_TimeBase2;

void main(void)
{
//===========================================================================
// Device and Application Initialization
//===========================================================================
	DeviceInit();	// Device Life support & GPIO

// wait for a valid SFO value from ePWM1
//	MEP_ScaleFactor[1] = 0;
//	while ( MEP_ScaleFactor[1] == 0 ) SFO_MepDis(1);
//	SFBUCK1n = MEP_ScaleFactor[1] * 256;	// used for HR BuckNloop		
//	SFBUCK2n = MEP_ScaleFactor[1] * 256;	// used for HR BuckNloop		

//---------------------- Used only if running from flash --------------------
#ifdef FLASH
// Copy time critical code and Flash setup code to RAM
// The  RamfuncsLoadStart, RamfuncsLoadEnd, and RamfuncsRunStart
// symbols are created by the linker. Refer to the linker files. 
	MemCopy(&RamfuncsLoadStart, &RamfuncsLoadEnd, &RamfuncsRunStart);

// Call Flash Initialization to setup flash waitstates
// This function must reside in RAM
	InitFlash();	// Call the flash wrapper init function
#endif
//---------------------------------------------------------------------------

//  SCIA_init();  					// Initalize the Serial Comms A peripheral
//	IRRC_Init();					// IR Remote control Initialisation *IRRC*
//	TimeBasePeriodCnf(9, 5000);		// Used for ISR MIPS guage.

// State-machine init
	Alpha_State_Ptr = &A0;
	A_Task_Ptr = &A1;
	B_Task_Ptr = &B1;
	C_Task_Ptr = &C1;

// PID coefficients & Clamping
	for(i=0; i<=NumChannels; i++)	Dmax[i] = 0;	// clamp all to 0% initially

	Pgain = 1;		Igain = 1;		Dgain = 5;		// very "loose"

// Coefficient init for Single Loop
	Coef2P2Z[0] = Dgain * 67108;							// B2
	Coef2P2Z[1] = (Igain - Pgain - Dgain - Dgain)*67108;	// B1
	Coef2P2Z[2] = (Pgain + Igain + Dgain)*67108;			// B0
	Coef2P2Z[3] = 0;										// A2 = 0
	Coef2P2Z[4] = 67108864;									// A1 = 1 in Q26
	Coef2P2Z[5] = Dmax[1] * 67108;							// Clamp Hi limit (Q26)
	Coef2P2Z[6] = 0x00000000;								// Clamp Lo

// Timing sync for background loops
	CpuTimer0Regs.PRD.all = T0PERIOD;	// see define above for value
	CpuTimer1Regs.PRD.all = T1PERIOD;	// see define above for value
	CpuTimer2Regs.PRD.all = T2PERIOD;	// see define above for value

// Soft start parameter initialisation
	SlewError = 0;
	StopAll =  0;			// Global shutdown flag
	StartUp = 0;			// Start / Stop flag
	SoftStartStatePtr = 0;	// Idle state first
	ActiveLoad = 0;			// Active Load 1 disabled initially
	ZeroNet = 0;
	Vref = 0;	Vtrgt = 0;	

	for(i=0; i<=NumChannels; i++)
	{
		VrefNetBus[i] = 0;
		UoutNetBus[i] = 0;
		Vtarget[i] = 0;
		Vsoft[i] = 0;
		ChannelEnable[i] = 0;
		SlewStep[i] = 200;
		Vmargin[i] = 0;
		TdegC[i] = 0;
		Vmeas[i] = 0;
		Imeas[i] = 0;
	}

	VinMeas = 0;
	BlinkStatePtr = 0;
	VTimer01 = 0;	VTimer11 = 0;
	CommsOKflg = 0;
	HRmode = 1;		// Default to HR mode enabled
	TempChSel = 0;
	LED_TaskPtr = 0;
	LED_Data = 0;
	BCptr = 0;
	TempBCptr = 0;
	
	LedOn[1] = 0x0001;
	LedOn[2] = 0x0002;
	LedOn[3] = 0x0004;
	LedOn[4] = 0x0008;
	LedOn[5] = 0x0010;
	LedOn[6] = 0x0020;
	LedOn[7] = 0x0040;
	LedOn[8] = 0x0080;

	LedOff[1] = 0x00FE;
	LedOff[2] = 0x00FD;
	LedOff[3] = 0x00FB;
	LedOff[4] = 0x00F7;
	LedOff[5] = 0x00EF;
	LedOff[6] = 0x00DF;
	LedOff[7] = 0x00BF;
	LedOff[8] = 0x007F;

// Configure ECAP1 - APWM Mode, used to control the Active Load #1
//-----------------------------------------------------------------
	ECap1Regs.ECCTL2.bit.CAP_APWM = 1;	// PWM mode
	ECap1Regs.ECCTL2.bit.APWMPOL = 0;	// ActiveHi
	ECap1Regs.TSCTR = 0;				// Zero the Time Stamp Counter
	ECap1Regs.CAP1 = 1000000;			// Period Register (1000 uS)
//	ECap1Regs.CAP2 =   80000;			// Compare Register(  80 uS)
	ECap1Regs.CAP2 =   50000;			// Compare Register(  50 uS)
	ECap1Regs.ECCTL2.bit.TSCTRSTOP = 1;	

// Configure SPI-A for LEDx8 interface
//-------------------------------------
	SpiaRegs.SPICCR.bit.SPISWRESET = 0;		// Hold SPI in reset
	SpiaRegs.SPIFFTX.bit.SPIRST = 0;		// Hold both FIFOs in reset
	SpiaRegs.SPIFFRX.bit.RXFIFORESET = 0;	// Hold RX FIFO in reset

	SpiaRegs.SPICCR.bit.SPICHAR = 7;		// 8 bit char
	SpiaRegs.SPICCR.bit.CLKPOLARITY = 1;	// LV595 Rcv on RE
	SpiaRegs.SPICCR.bit.SPILBK = 0;			// No Loopback
	SpiaRegs.SPIBRR = 0x08;					// Baud rate select
	
	SpiaRegs.SPICTL.bit.MASTER_SLAVE = 1;	// Master mode
	SpiaRegs.SPICTL.bit.CLK_PHASE = 0;		// SPI Outputs on FE
	SpiaRegs.SPICTL.bit.OVERRUNINTENA = 0;	// Disable
	SpiaRegs.SPICTL.bit.TALK = 1;			// Enable TX
	SpiaRegs.SPICTL.bit.SPIINTENA = 0;		// Disable
    SpiaRegs.SPIPRI.bit.FREE = 1;			// Set so brkpts don't disturb xmission

	SpiaRegs.SPIFFRX.bit.RXFFIL = 3;		// Set flag after 3 bytes rcv'd
	SpiaRegs.SPIFFRX.bit.RXFFINTCLR = 1;	// Clear any spurious Int Flag

	SpiaRegs.SPICCR.bit.SPISWRESET = 1;		// Release SPI from reset
	SpiaRegs.SPIFFRX.bit.RXFIFORESET = 1;	// Release RX FIFO from reset
	SpiaRegs.SPIFFTX.bit.SPIRST = 1;		// Release both FIFOs from reset
	SpiaRegs.SPIFFTX.bit.SPIFFENA = 1;		// Enable FIFOs feature

//---------------------------------------------------------------------------
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// Incremental build options via Module connections to system Nets.
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//=============================================================
#if (IB1) 	// Open loop - Channels 1,2
//=============================================================
#define		prd			333	// Period count = 300 KHz @ 100 MHz
#define		NumActvCh	2	// Number of Active Channels

// "Raw" (R) ADC measurement name defines
#define		VoutR1	 AdcMirror.ADCRESULT0	//
#define		VoutR2	 AdcMirror.ADCRESULT1	//
#define		IoutR1	 AdcMirror.ADCRESULT2	//
#define		IoutR2	 AdcMirror.ADCRESULT3	//
#define		TempR1	 AdcMirror.ADCRESULT4	//
#define		TempR2	 AdcMirror.ADCRESULT5	//
#define		VinR	 AdcMirror.ADCRESULT6	//

	// Channel Selection for Cascaded Sequencer
	ChSel[0] = 8;		// B0 - Vout1
	ChSel[1] = 0;		// A0 - Vout2
	ChSel[2] = 9;		// B1 - Iout1
	ChSel[3] = 1;		// A1 - Iout2
	ChSel[4] = 10;		// B2 - Temperature-1
	ChSel[5] = 2;		// A2 - Temperature-2
	ChSel[6] = 11;		// B3 - Vin

	BuckSingle_CNF(1, prd, 1, 0);	// ePWM1, Period=prd, Master, Phase=Don't Care
	BuckSingle_CNF(2, prd, 0, 0);	// ePWM2, Period=prd, Slave,  Phase=0
	ADC_CascSeqCNF(ChSel, 2, 7, 1);	// ACQPS=2, #Conv=7, Mode=Continuous
	EPwm1Regs.CMPB = 2;				// ISR trigger point
	ISR_Init();						// ASM ISR init

	Duty1 = 0x0;
	Duty2 = 0x0;
	
// Module connection to "nets" done here
//----------------------------------------
// BUCK_DRV connections
	Buck_In1 = &Duty1;
	Buck_In2 = &Duty2;

#endif // (IB1)


//=====================================================================
#if (IB2) // Closed Loop Ch-1, with SoftStart using separate lib blocks
//=====================================================================
#define		prd		400		// Period count = 250 KHz @ 100 MHz
//#define	prd		333		// Period count = 300 KHz @ 100 MHz
//#define	prd		250		// Period count = 400 KHz @ 100 MHz
//#define	prd		200		// Period count = 500 KHz @ 100 MHz

#define		NumActvCh	1	// Number of Active Channels

// "Raw" (R) ADC measurement name defines
#define		VoutR1	 AdcMirror.ADCRESULT0	//

#define		VoutR2	 AdcMirror.ADCRESULT8	//
#define		IoutR1	 AdcMirror.ADCRESULT9	//
#define		IoutR2	 AdcMirror.ADCRESULT10	//
#define		TempR1	 AdcMirror.ADCRESULT11	//
#define		TempR2	 AdcMirror.ADCRESULT12	//
#define		VinR	 AdcMirror.ADCRESULT13	//


	OnDelay[1] =	0;
	OffDelay[1] =	0;
	Vsoft[1] =		10900;	// 1.8 V
	SlewStep[1] = 	200;
	DataLogTrigger = 980000;
	ScopeGain = 1;
	ScopeACmode = 0;	// DC mode initially

	// Channel Selection for Sequencer-1
	ChSel[0] = 8;		// B0 - Vout1

	// Channel Selection for Sequencer-2
	ChSel[8] =  0;		// A0 - Vout2
	ChSel[9] = 9;		// B1 - Iout1
	ChSel[10] = 1;		// A1 - Iout2
	ChSel[11] = 10;		// B2 - Temperature-1
	ChSel[12] = 2;		// A2 - Temperature-2
	ChSel[13] = 11;		// B3 - Vin

	BuckSingle_CNF(1, prd, 1, 0);		// ePWM1, Period=prd, Master, Phase=0
	EPwm1Regs.CMPB = 193;				// tCMPB1 - ISR trigger point
//	EPwm2Regs.CMPB = 120;				// tCMPB2 - ADC SOS trigger point
//	EPwm2Regs.CMPB = 60;				// tCMPB2 - ADC SOS trigger point
	ADC_DualSeqCNF(ChSel, 1, 1, 1);		// ACQPS=1, Seq1#Conv=1, Seq2#Conv=1
	ISR_Init();							// ASM ISR init

// Lib Module connection to "nets" 
//--------------------------------
// ADC1CH_DRV connections
	ADC_Rslt = &Vfdbk;
// CNTL_2P2Z connections
	CNTL_2P2Z_Ref1 = &VrefNetBus[1];	// point to Vref from SlewRate limiter
	CNTL_2P2Z_Out1 = &Uout;				// point to Uout
	CNTL_2P2Z_Fdbk1 = &Vfdbk;			// point to Vfdbk
	CNTL_2P2Z_Coef1 = &Coef2P2Z[0];		// point to first coeff for Single Loop
// BUCK_DRV connections
	Buck_In1 = &Uout;

// Data Logger connections, DLTST = DataLogTimeStampTrigger
	DLTST_In1 = &Vfdbk;
	DLTST_TimeBase1 = &ECap1Regs.TSCTR;
	DLTST_TimeStampTrig1 = &DataLogTrigger;
	DLTST_DcOffset1 = 0;
	DLTST_Gain1 = ScopeGain;

// Trigger ADC SOCA & B from EPWM1
//----------------------------------------
	EPwm1Regs.ETSEL.bit.SOCASEL = ET_CTRU_CMPB;		// SOCA on CMPB event
	EPwm1Regs.ETSEL.bit.SOCBSEL = ET_CTRU_CMPB;		// SOCB on CMPB event
	EPwm1Regs.ETSEL.bit.SOCAEN = 1;					// Enable SOC on A group
	EPwm1Regs.ETSEL.bit.SOCBEN = 1;					// Enable SOC on B group
	EPwm1Regs.ETPS.bit.SOCAPRD = ET_1ST;			// Trigger on every event
	EPwm1Regs.ETPS.bit.SOCBPRD = ET_1ST;			// Trigger on every event

#endif // (IB2)


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// Interrupt Init section - System Level and Peripheral Level
// (best to run this section last, once all other initialization is done)
//===========================================================================
	EALLOW;
	PieVectTable.EPWM1_INT = &ISR_Run;			// Map Interrupt
	EDIS;
	PieCtrlRegs.PIEIER3.bit.INTx1 = 1;			// PIE level enable, Grp3 / Int1
	//EPwm1Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;	// INT on Zero event
	EPwm1Regs.ETSEL.bit.INTSEL = ET_CTRU_CMPB;	// INT on CMPB event
	EPwm1Regs.ETSEL.bit.INTEN = 1;				// Enable INT
	EPwm1Regs.ETPS.bit.INTPRD = ET_1ST;			// Generate INT on every event
//===========================================================================
// Enable Peripheral, global Ints and higher priority real-time debug events:
//===========================================================================
	IER |= M_INT3;	// Enable CPU INT3 connected to EPWM1-6 INTs:
	EINT;   		// Enable Global interrupt INTM
	ERTM;   		// Enable Global realtime interrupt DBGM
//===========================================================================

// Backgound Loop
	for(;;)
	{
		// State machine entry & exit point
		//===========================================================
		(*Alpha_State_Ptr)();	// jump to an Alpha state (A0,B0,...)
		//===========================================================

	}
} 


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// Alpha (A, B, C,...) State sequence control
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
void A0(void)
{
	// loop rate synchronizer for A-tasks
	if(CpuTimer0Regs.TCR.bit.TIF == 1)
	{
		CpuTimer0Regs.TCR.bit.TIF = 1;	// clear flag

		//===========================================================
		(*A_Task_Ptr)();		// jump to an A Task (A1,A2,A3,...)
		//===========================================================

		VTimer01++;				// Virtual Timer 0, instance 1		
	}

	Alpha_State_Ptr = &B0;		// Comment out to allow only A tasks
}

void B0(void)
{
	// loop rate synchronizer for B-tasks
	if(CpuTimer1Regs.TCR.bit.TIF == 1)
	{
		CpuTimer1Regs.TCR.bit.TIF = 1;				// clear flag

		//===========================================================
		(*B_Task_Ptr)();		// jump to a B Task (B1,B2,B3,...)
		//===========================================================
		VTimer11++;				// Virtual Timer 1, instance 1		
	}

	Alpha_State_Ptr = &C0;	
}

void C0(void)
{
	// loop rate synchronizer for C-tasks
	if(CpuTimer2Regs.TCR.bit.TIF == 1)
	{
		CpuTimer2Regs.TCR.bit.TIF = 1;				// clear flag

		//===========================================================
		(*C_Task_Ptr)();		// jump to a C Task (C1,C2,C3,...)
		//===========================================================
		VTimer21++;				// Virtual Timer 2, instance 1		
	}

	Alpha_State_Ptr = &A0;	// Back to State A0
}


//%%%%%%%%%%%%%%%    A-Tasks:   %%%%%%%%%%%%%%%%%%%%%%%%%
//=====================================================================
void A1(void) // Sequencing & delayed On/Off Control 
//=====================================================================
{
	// Sequencing State machine
	switch(SoftStartStatePtr)
	{
		case 0:	// Idle - waiting for start command
			if(StartUp == 1)
			{
				SoftStartStatePtr = 1;
				DelayCtr = 0;
			}
			break;

		case 1:	// Enable each Output according to it's delay time 
			DelayCtr++;
			ChannelCtr=0;

			for(i=1; i<=NumActvCh; i++)
			{
				if(DelayCtr >= OnDelay[i])	ChannelEnable[i] = 1;
				ChannelCtr = ChannelCtr + ChannelEnable[i];
			}

			if(ChannelCtr == NumActvCh)	SoftStartStatePtr = 2;

			break;

		case 2:	// Regulated - "At Voltage" state
			if(StartUp == 0)
			{
				SoftStartStatePtr = 3;
				DelayCtr = 0;
			}
			break;

		case 3:	// Shut-Down each Output according to it's delay time 
			DelayCtr++;
			ChannelCtr=NumActvCh;

			for(i=1; i<=NumActvCh; i++)
			{
				if(DelayCtr >= OffDelay[i])	ChannelEnable[i] = 0;
				ChannelCtr = ChannelCtr - ChannelEnable[i];
			}

			if(ChannelCtr == NumActvCh)	SoftStartStatePtr = 0;

			break;
	}

	// Channel On/Off control
	for(i=1; i<=NumActvCh; i++)
	{
		if(ChannelEnable[i] == 1)
		{
			Vtarget[i] = Vsoft[i] + Vmargin[i];
			Dmax[i] = DMAX1;
//			LED_Data = LED_Data | LedOn[i];			// Set appropriate LED bit

		}
		else
		{
			Vtarget[i] = 0;
			// wait till Vref=0, then clamp respective output
			if(VrefNetBus[i]==0)
			{
				Dmax[i] = 0;
//				LED_Data = LED_Data & LedOff[i];	// Clear appropriate LED bit
			}
		}
	}

	// All Channel shut-down control
	if(StopAll == 1)
	{
		for(i=1; i<=NumActvCh; i++)
		{
			ChannelEnable[i] = 0;
		}		
	
		SoftStartStatePtr = 0;
		StartUp = 0;
		StopAll = 0;
	}

	//-------------------
	A_Task_Ptr = &A2;
	//-------------------
}

//=====================================================================
void A2(void) // Slew Rate ("soft-start") & Dmax Clamping
//=====================================================================
{
	for(i=1; i<=NumActvCh; i++)
	{
		SlewError = (VrefNetBus[i] - Vtarget[i]);
		if (SlewError > SlewStep[i])		VrefNetBus[i] = VrefNetBus[i] - SlewStep[i];
		else
		if (SlewError < (-SlewStep[i]) )	VrefNetBus[i] = VrefNetBus[i] + SlewStep[i];
		else								VrefNetBus[i] = Vtarget[i];
	}

	//  Dmax Clamping
	Coef2P2Z[5] = 	Dmax[1] * 67108;
	Coef2P2Z_1[1] = Dmax[1] * 67108;
	Coef2P2Z_2[1] = Dmax[2] * 67108;

	//-------------------
	A_Task_Ptr = &A1;
	//-------------------
}

//=======================================================================
void A3(void) // SPARE (not active)
//=======================================================================
{

	//-----------------
	A_Task_Ptr = &A1;
	//-----------------
}

//=====================================================================
void A4(void) //  SPARE (not active)
//=====================================================================
{

	//-----------------
	A_Task_Ptr = &A1;	
	//-----------------
}


//%%%%%%%%%%%%%%%    B-Tasks:   %%%%%%%%%%%%%%%%%%%%%%%%%
//=====================================================================
void B1(void) // Voltage Dashboard measurements
//=====================================================================
{
// Voltage measurement calculated by:
//
//	Vmeas = VoutADC * Kv,	VinMeas = VinADC * Kvi
//
//	where 	VoutADC, VinADC is in counts (0-4096)	(Q0 in 32 bit word)
//			Kv = 0.00131	= 43			(Q15 in 32 bit word)
//			Kvi = 0.00407	= 133			(Q15 in 32 bit word)

	BCptr++;
	if (BCptr >= 8)	BCptr = 0;

	Kv = 48;	// for R1=330 ohm / R2 = 330
	//Kv = 43;	// for R1=270 ohm / R2 = 330
	Kvi = 133;

	// BoxCar Averages - Input Raw samples into BoxCar arrays
	//----------------------------------------------------------------
	VoutH1[BCptr] = VoutR1;
	VoutH2[BCptr] = VoutR2;
	VinH[BCptr]   = VinR;

	// Voltage Meas
	//----------------------------------------------------------------
	Scratch=0;
	for(i=0; i<8; i++)	Scratch = Scratch + VoutH1[i];
	Dmy1 = ( (long)(Scratch>>3) * Kv);	// Q15 in 32
	Vmeas[1] = Dmy1 & 0xFFFFFC00;

	Scratch=0;
	for(i=0; i<8; i++)	Scratch = Scratch + VoutH2[i];
	Dmy1 = ( (long)(Scratch>>3) * Kv);	// Q15 in 32
	Vmeas[2] = Dmy1 & 0xFFFFFC00;

	Scratch=0;
	for(i=0; i<8; i++)	Scratch = Scratch + VinH[i];
	Dmy1 = ( (long)(Scratch>>3) * Kvi);	// Q15 in 32
	VinMeas = Dmy1 & 0xFFFFFC00;

	//-----------------
	B_Task_Ptr = &B2;	
	//-----------------
}

//=====================================================================
void B2(void) // Current Dashboard measurements
//=====================================================================
{
// Current measurement calculated by:
//
//	Imeas = (IoutADC * Ki) - Izero
//
//	where 	IoutADC is in counts (0-4096)	(Q0 in 32 bit word)
//			Ki = 0.0083	= 272				(Q15 in 32 bit word)
//			Izero = 6.93 = 227082			(Q15 in 32 bit word)

	Ki = 272;
	Izero = 227082;

	// BoxCar Averages - Input Raw samples into BoxCar arrays
	IoutH1[BCptr] = IoutR1;
	IoutH2[BCptr] = IoutR2;

	// Current Meas
	//----------------------------------------------------------------
	Scratch=0;
	for(i=0; i<8; i++)	Scratch = Scratch + IoutH1[i];
	Dmy1 = ( (long)(Scratch>>3) * Ki) - Izero;	// Q15 in 32
	if (Dmy1 < 0)	Imeas[1]=0;	else Imeas[1] = Dmy1 & 0xFFFFF000;

	Scratch=0;
	for(i=0; i<8; i++)	Scratch = Scratch + IoutH2[i];
	Dmy1 = ( (long)(Scratch>>3) * Ki) - Izero;	// Q15 in 32
	if (Dmy1 < 0)	Imeas[2]=0;	else Imeas[2] = Dmy1 & 0xFFFFF000;
	//-----------------
	B_Task_Ptr = &B3;
	//-----------------
}

//=====================================================================
void B3(void) //  Temperature Dashboard measurements
//=====================================================================
{
// Temperature measurement calculated by:
//
//	TdegC = (TempADC * Kt) - Tzero
//
//	where 	TempADC is in counts (0-4096)	(Q0 in 32 bit word)
//			Kt = 0.0732	= 2399				(Q15 in 32 bit word)
//			Tzero = 50						(Q0 in 16 bit word)

	Tzero = 50;
	Kt = 2399;

	// BoxCar Averages - Input Raw samples into BoxCar arrays
	DegCH1[BCptr] = TempR1;
	DegCH2[BCptr] = TempR2;

	// Temperature Meas
	//----------------------------------------------------------------
	Scratch=0;
	for(i=0; i<8; i++)	Scratch = Scratch + DegCH1[i];
	Dmy1 = ( (long)(Scratch>>3) * Kt) - (Tzero<<15);	// Q15 in 32
	TdegC[1] = Dmy1 & 0xFFFFC000;

	Scratch=0;
	for(i=0; i<8; i++)	Scratch = Scratch + DegCH2[i];
	Dmy1 = ( (long)(Scratch>>3) * Kt) - (Tzero<<15);	// Q15 in 32
	TdegC[2] = Dmy1 & 0xFFFFC000;

	//-----------------
	B_Task_Ptr = &B1;	
	//-----------------
}

//=====================================================================
void B4(void) //  SPARE (not active)
//=====================================================================
{

	//-----------------
	B_Task_Ptr = &B1;	
	//-----------------
}



//%%%%%%%%%%%%%%%    C-Tasks:   %%%%%%%%%%%%%%%%%%%%%%%%%
//=====================================================================
void C1(void) // Coefficient and Active load update / control
//=====================================================================
{

// Coefficient Update for Single Loop
	Coef2P2Z[0] = Dgain * 67108;							// B2
	Coef2P2Z[1] = (Igain - Pgain - Dgain - Dgain)*67108;	// B1
	Coef2P2Z[2] = (Pgain + Igain + Dgain)*67108;			// B0

	EALLOW;
	if (ActiveLoad ==1)		GpioCtrlRegs.GPAMUX2.bit.GPIO24 = 1;	// ECAP-1
	else					GpioCtrlRegs.GPAMUX2.bit.GPIO24 = 0;	// GPIO

	if (HRmode ==1)			EPwm1Regs.HRCNFG.bit.EDGMODE = HR_FEP;	// Enable
	else					EPwm1Regs.HRCNFG.bit.EDGMODE = HR_Disable;
	EDIS;

	//-----------------
	C_Task_Ptr = &C2;	
	//-----------------
}

//=====================================================================
void C2(void) //  LED control
//=====================================================================
{
  	if (CommsOKflg == 0)	// If Host not responding, Blink LED4
  	{
		//LED4 blink indicates Slave is waiting for Host comms
	  switch(BlinkStatePtr)
	  {
		case 0:	// 
		if(VTimer11 > 200)	// 200*8mS = 1.6 sec
		{
			GpioDataRegs.GPBCLEAR.bit.GPIO34=1;	//LED4-ON
			LED_Data = 0x55;	// debug 8xLED only
			VTimer11 = 0;
			BlinkStatePtr = 1;
		}
		break;

		case 1:	// 
		if(VTimer11 > 10)	// 10*8mS = 0.08 sec
		{
			GpioDataRegs.GPBSET.bit.GPIO34=1;	//LED4-OFF
			LED_Data = 0xAA;	// debug 8xLED only
			VTimer11 = 0;
			BlinkStatePtr = 0;
		}
		break;
	  }
  	}

  	// LED x8 Display routine using SPI-A
  	switch(LED_TaskPtr)
	{
		case 0:	// Send Data
			GpioDataRegs.GPACLEAR.bit.GPIO19 = 1;	// Set R-CLK Low
			SpiaRegs.SPITXBUF=(LED_Data<<8);		// Left Justify data
			LED_TaskPtr = 1;
			break;

		case 1:	// Latch data
			GpioDataRegs.GPASET.bit.GPIO19 = 1;		// Set R-CLK High
			LED_TaskPtr = 0;
			break;
	}	


#if (IB2) 	// Use scope only on IB2
	// Scope Control
	DLTST_Gain1 = ScopeGain;

	if (ScopeACmode == 1)	DLTST_DcOffset1 = Vsoft[1];
	else					DLTST_DcOffset1 = 0;
#endif // (IB2)

	//-----------------
	C_Task_Ptr = &C1;	
	//-----------------
}

//=====================================================================
void C3(void) //  SPARE (not active)
//=====================================================================
{

	//-----------------
	C_Task_Ptr = &C1;	
	//-----------------
}

//=====================================================================
void C4(void) //  SPARE (not active)
//=====================================================================
{

	//-----------------
	C_Task_Ptr = &C1;	
	//-----------------
}




