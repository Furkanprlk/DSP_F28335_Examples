//----------------------------------------------------------------------------------
//	FILE:			PWMexplore-Main.C
//
//	Description:	PWM waveform generation for various power stage topologies
//					Allows open loop adjust of duty, phase, dead-band...etc
//
//	Version: 		1.0
//
//  Target:  		TMS320F280x / F28044
//
//----------------------------------------------------------------------------------
//  Copyright Texas Instruments � 2007
//----------------------------------------------------------------------------------
//  Revision History:
//----------------------------------------------------------------------------------
//  Date	  | Description / Status
//----------------------------------------------------------------------------------
//  08/22/07  | Release 1.0 
//----------------------------------------------------------------------------------
//  MM/DD/YY  | Release x.?  		
//----------------------------------------------------------------------------------

#include "DSP280x_Device.h"
#include "DSP280x_EPWM_defines.h" 	// useful defines for initialization

// System specific function prototypes here
//---------------------------------------------------------------
void ISR_Init(void);
void ISR_Run(void);
void ISR_BldTbl(void);
void ISR_Pseudo(void);
void DeviceInit(void);
void TimeBaseGenCNF(int n, int period);
void BuckSingle_CNF(int n, int period, int mode, int phase);
void BuckDual_CNF(int n, int period, int mode, int phase);
void MPhIL_CNF(int n, int N, int period, int mode);
void FullBridgePS_CNF(int n, int prd);
void FullBridgeIBM_CNF(int n, int prd);
void PFC2PhIL_CNF(int n, int prd);
void ADC_CascSeqCNF(int ScopeChSel[], int acqps, int Nconv, int Continuous);

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// State Machine function prototypes and related stuff
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// Alpha states
void A0(void);	//state A0
void B0(void);	//state B0
void C0(void);	//state C0

// A branch states
void A1(void);	//state A1
void A2(void);	//state A2
void A3(void);	//state A3

// B branch states
void B1(void);	//state B1
void B2(void);	//state B2
void B3(void);	//state B3

// C branch states
void C1(void);	//state C1
void C2(void);	//state C2
void C3(void);	//state C3


// Variable declarations
void (*Alpha_State_Ptr)(void);	// Base States pointer
void (*A_Task_Ptr)(void);		// State pointer A branch
void (*B_Task_Ptr)(void);		// State pointer B branch
void (*C_Task_Ptr)(void);		// State pointer C branch

//===============================================================
// State Machine Sync timers period definition
//---------------------------------------------------------------
#define	T0PERIOD	 66666	//  667 uS (0.667 mS) - A tasks
#define	T1PERIOD	400000	// 4000 uS (4.000 mS) - B tasks
#define	T2PERIOD	100000	// 1000 uS (1.000 mS) - C tasks


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// Variable Declarations
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// General System nets & parameters
int16	i;
int16	ZeroNet, BlackHoleNet;

int16	VTimer01, VTimer02, VTimer03; // Virtual Timers slaved of CPU Timer 0
int16	VTimer11, VTimer12, VTimer13; // Virtual Timers slaved of CPU Timer 1
int16	VTimer21, VTimer22, VTimer23; // Virtual Timers slaved of CPU Timer 2
int16 	MEP_ScaleFactor[5];
int16	ScopeChSel[16];

Uint16	BuildStatePtr, Update, ConfigOption, CurrentConfigOption;
Uint16	BlinkStatePtr, CommsOKflg;

int16	InOutDiff, OutVal, InVal, RampStep;
int16	Duty1, Duty2, Duty3, Duty4;
int16	Duty, DelLL, DelLR;				// for FullBridgeIBM
int16	Phase, DbLeft, DbRight;			// for FullBridgePS
int16	ScopeTrigger, ScopeTimeBase;

// Used to indirectly access all EPWM modules, very useful!
volatile struct EPWM_REGS *ePWM[] = 
 				  { &EPwm1Regs,
					&EPwm1Regs,				  
					&EPwm2Regs,
					&EPwm3Regs,
					&EPwm4Regs,
					&EPwm5Regs,
					&EPwm6Regs,
//					&EPwm7Regs,
//					&EPwm8Regs,
//					&EPwm9Regs,
//					&EPwm10Regs
					};

extern int16 *RamfuncsLoadStart, *RamfuncsLoadEnd, *RamfuncsRunStart;

// ASM Module Terminal pointers and Variable here
//===========================================================================
// Buck - Single, Dual
extern int16	*Buck_In1, *Buck_In2, *Buck_In3, *Buck_In4;
extern int16	*Buck_InA1, *Buck_InA2, *Buck_InA3, *Buck_InA4;
extern int16	*Buck_InB1, *Buck_InB2, *Buck_InB3, *Buck_InB4;
// Multi-phase Interleaved (MPhIL)
extern int16	*MPhIL_In1, *MPhIL_In2, *MPhIL_In3, *MPhIL_In4;
// Full Bridge - Phase Shifted method
extern int16	*FBPS_phase1, *FBPS_dbLeft1, *FBPS_dbRight1;
extern int16	*FBPS_phase2, *FBPS_dbLeft2, *FBPS_dbRight2;
extern int16	*FBPS_phase3, *FBPS_dbLeft3, *FBPS_dbRight3;
// Full Bridge - IBM method
extern int16	*FBI_In1, *FBI_delLL1, *FBI_delLR1;
extern int16	*FBI_In2, *FBI_delLL2, *FBI_delLR2;
extern int16	*FBI_In3, *FBI_delLL3, *FBI_delLR3;
extern int16	HRSF1, HRSF2, HRSF3, HRSF4, TBcntl, IBnmbr;
// PFC 2-phase Interleaved
extern int16	*PFC2Ph_In1, *PFC2Ph_In2, *PFC2Ph_In3;

void main(void)
{
//===========================================================================
// Device and Application Initialization
//===========================================================================
	DeviceInit();	// Device Life support & GPIO

#ifdef FLASH
// Copy time critical code and Flash setup code to RAM
// The  RamfuncsLoadStart, RamfuncsLoadEnd, and RamfuncsRunStart
// symbols are created by the linker. Refer to the linker files. 
	MemCopy(&RamfuncsLoadStart, &RamfuncsLoadEnd, &RamfuncsRunStart);

// Call Flash Initialization to setup flash waitstates
// This function must reside in RAM
	InitFlash();	// Call the flash wrapper init function
#endif

//  SCIA_init();  					// Initalize the Serial Comms A peripheral
//	TimeBasePeriodCnf(9, 5000);		// Used for ISR MIPS guage.

// State-machine init
	Alpha_State_Ptr = &A0;
	A_Task_Ptr = &A1;
	B_Task_Ptr = &B1;
	C_Task_Ptr = &C1;

// Timing sync for background loops
	CpuTimer0Regs.PRD.all = T0PERIOD;	// see define above for value
	CpuTimer1Regs.PRD.all = T1PERIOD;	// see define above for value
	CpuTimer2Regs.PRD.all = T2PERIOD;	// see define above for value

	ZeroNet = 0;

	ConfigOption = 1;			// Start with Build 1
	CurrentConfigOption = 0;
	BuildStatePtr = 0;
	BlinkStatePtr = 0;
	VTimer01 = 0;	VTimer02 = 0;	VTimer03 = 0;
	CommsOKflg = 0;
	ScopeTimeBase = 0;
	ScopeTrigger = 10;

//----------------------------------------------------------------------
// "Virtual" Scope setup for probing PWM outputs with ADC
//----------------------------------------------------------------------
#define		prd		10000				// Period count = 10 KHz @ 100 MHz
#define		acqps	3					// Acquisition prescaler
#define		Nconv	4					// Number of conversions
#define		StartStop	0				// ADC Conv Mode
#define		Continuous	1				// ADC Conv Mode
//----------------------------------------------------------------------
#define		Epwm3A	7					// ADC-A7 connected to EPWM-3A
#define		Epwm4A	6					// ADC-A6 connected to EPWM-4A
#define		Epwm5A	5					// ADC-A5 connected to EPWM-5A
#define		Epwm6A	4					// ADC-A4 connected to EPWM-5A
#define		GND_ref	3					// ADC-A3 connected to 0V (GND)
//----------------------------------------------------------------------
#define		Epwm3B	15					// ADC-B7 connected to EPWM-3B
#define		Epwm4B	14					// ADC-B6 connected to EPWM-4B
#define		Epwm5B	13					// ADC-B5 connected to EPWM-5B
#define		Epwm6B	12					// ADC-B4 connected to EPWM-5B


// Scope Timebase and Sampling config
	TimeBaseGenCNF(2, prd);				// Used for ISR trigger only

// Interrupt setup to drive the Scope
	EALLOW;
	PieVectTable.EPWM2_INT = &ISR_Run;			// Map Interrupt
	EDIS;
	PieCtrlRegs.PIEIER3.bit.INTx2 = 1;			// PIE level enable, Grp3 / Int2
	EPwm2Regs.ETSEL.bit.INTSEL = ET_CTRU_CMPB;	// INT on CMPB event
	EPwm2Regs.ETSEL.bit.INTEN = 1;				// Enable INT
	EPwm2Regs.ETPS.bit.INTPRD = ET_3RD;			// Generate INT every 3rd event
	EPwm2Regs.CMPB = 0;							// ISR trigger point

//----------------------------------------------------------------------
// Interrupt Init section - System Level and Peripheral Level
// (best to run this section last, once all other initialization is done)
//----------------------------------------------------------------------
	IER |= M_INT3;	// Enable CPU INT3 connected to EPWM1-6 INTs:
	EINT;   		// Enable Global interrupt INTM
	ERTM;			// Enable Global realtime interrupt DBGM
//----------------------------------------------------------------------


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// Backgound Loop
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	for(;;)
	{
		// "Reconfigure" State machine
		switch(BuildStatePtr)
		{
			case 0:	// Idle - waiting for an Update command

				if(ConfigOption != CurrentConfigOption)
				{
					BuildStatePtr = ConfigOption;
					CurrentConfigOption = ConfigOption;
				}
				break;

			case 1:	// 2 x Single Buck
				IBnmbr = 0;					 // IB1
				BuckSingle_CNF(3, prd, 1, 0);// ePWM3, Period=prd, Master, Phase=0
				BuckSingle_CNF(4, prd, 0, 0);// ePWM4, Period=prd, Slave,  Phase=0
				ISR_BldTbl();
				ISR_Init();					// ASM ISR init				
				Duty1 = 	0xA00;
				Duty2 = 	0xF00;

				// Module connection to "nets" 
				//----------------------------
				Buck_In3 = &Duty1;
				Buck_In4 = &Duty2;

				ScopeChSel[0] = Epwm3A;
				ScopeChSel[1] = Epwm4A;
				ScopeChSel[2] = GND_ref;
				ScopeChSel[3] = GND_ref;

				BuildStatePtr = 10;
				break;

			case 2:	// Dual Buck
				IBnmbr = 2;					// IB2
				BuckDual_CNF(3, prd, 1, 0);	// ePWM3, Period=prd, Master, Phase=0
				ISR_BldTbl();
				ISR_Init();					// ASM ISR init				
				Duty1 = 	0xA00;
				Duty2 = 	0xF00;

				// Module connection to "nets" 
				//----------------------------
				Buck_InA3 = &Duty1;
				Buck_InB3 = &Duty2;				

				ScopeChSel[0] = Epwm3A;
				ScopeChSel[1] = Epwm3B;
				ScopeChSel[2] = GND_ref;
				ScopeChSel[3] = GND_ref;

				BuildStatePtr = 10;
				break;

			case 3:	// Multi-Phase Buck
				IBnmbr = 4;					// IB3
				MPhIL_CNF(3, 4, prd, 0);	// Start at ePWM3, 4 phases, no SyncIn
				ISR_BldTbl();
				ISR_Init();					// ASM ISR init				
				Duty1 = 0xA00;

				// Module connection to "nets" 
				//----------------------------
				MPhIL_In3 = &Duty1;

				ScopeChSel[0] = Epwm3A;
				ScopeChSel[1] = Epwm4A;
				ScopeChSel[2] = Epwm5A;
//				ScopeChSel[3] = Epwm6A;
				ScopeChSel[3] = Epwm6B;	// only for BH280xxLC - bug

				BuildStatePtr = 10;
				break;

			case 4:	// Full bridge using Phase Shifting method
				IBnmbr = 6;					// IB4
				FullBridgePS_CNF(3, prd);	// ePWM3, Period=prd
				ISR_BldTbl();
				ISR_Init();					// ASM ISR init				
				Phase =	0xA00;
				DbLeft = 0x0;
				DbRight = 0x0;
	
				// Module connection to "nets" 
				//----------------------------
				FBPS_phase3 = &Phase;
				FBPS_dbLeft3 = &DbLeft;
				FBPS_dbRight3 = &DbRight;				

				ScopeChSel[0] = Epwm3A;
				ScopeChSel[1] = Epwm3B;
				ScopeChSel[2] = Epwm4A;
				ScopeChSel[3] = Epwm4B;

				BuildStatePtr = 10;
				break;

			case 5:	// Full bridge using IBM method
				IBnmbr = 8;					// IB5
				FullBridgeIBM_CNF(3, prd);	// ePWM3/4, Period=prd
				ISR_BldTbl();
				ISR_Init();					// ASM ISR init				
				Duty1 = 0xA00;
				DelLL = 0x0;
				DelLR = 0x0;
	
				// Module connection to "nets" 
				//----------------------------
				FBI_In3 = &Duty1;
				FBI_delLL3 = &DelLL;
				FBI_delLR3 = &DelLR;

				ScopeChSel[0] = Epwm3A;
				ScopeChSel[1] = Epwm3B;
				ScopeChSel[2] = Epwm4A;
				ScopeChSel[3] = Epwm4B;

				BuildStatePtr = 10;
				break;

			case 6:	// PFC 2-phase Interleaved
				IBnmbr = 10;				// IB6
				PFC2PhIL_CNF(3, prd);		// ePWM3/4, Period=prd
				ISR_BldTbl();
				ISR_Init();					// ASM ISR init				
				Duty1 = 0xA00;
	
				// Module connection to "nets" 
				//----------------------------
				PFC2Ph_In3 = &Duty1;

				ScopeChSel[0] = Epwm3A;
				ScopeChSel[1] = Epwm4A;
				ScopeChSel[2] = GND_ref;
				ScopeChSel[3] = GND_ref;

				BuildStatePtr = 10;
				break;

			case 10:// General

				ADC_CascSeqCNF(ScopeChSel, acqps, Nconv, Continuous);
				BuildStatePtr = 0;		// Back to Idle state
				break;

		}

		// Task State machine entry & exit point
		//===========================================================
		(*Alpha_State_Ptr)();	// jump to an Alpha state (A0,B0,...)
		//===========================================================
	}
} 


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// Alpha (A, B, C,...) State sequence control
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
void A0(void)
{
	// loop rate synchronizer for A-tasks
	if(CpuTimer0Regs.TCR.bit.TIF == 1)
	{
		CpuTimer0Regs.TCR.bit.TIF = 1;				// clear flag

		//===========================================================
		(*A_Task_Ptr)();		// jump to an A Task (A1,A2,A3,...)
		//===========================================================
	}


	Alpha_State_Ptr = &B0;	
}

void B0(void)
{
	// loop rate synchronizer for B-tasks
	if(CpuTimer1Regs.TCR.bit.TIF == 1)
	{
		CpuTimer1Regs.TCR.bit.TIF = 1;				// clear flag

		//===========================================================
		(*B_Task_Ptr)();		// jump to a B Task (B1,B2,B3,...)
		//===========================================================
		VTimer01++;	VTimer02++;	VTimer03++;
	}

	Alpha_State_Ptr = &C0;	
}

void C0(void)
{
	// loop rate synchronizer for C-tasks
	if(CpuTimer2Regs.TCR.bit.TIF == 1)
	{
		CpuTimer2Regs.TCR.bit.TIF = 1;				// clear flag

		//===========================================================
		(*C_Task_Ptr)();		// jump to a C Task (C1,C2,C3,...)
		//===========================================================
	}

	Alpha_State_Ptr = &A0;	// Back to State A0
}


//%%%%%%%%%%%%%%%    A-Tasks:   %%%%%%%%%%%%%%%%%%%%%%%%%
//=====================================================================
void A1(void) // 
//=====================================================================
{

	ISR_Pseudo();						// Call asm PWM drivers

	EPwm2Regs.CMPB = ScopeTrigger;		// ISR trigger point


//	EPwm4Regs.TBPHS.half.TBPHS = Phase;


	//-------------------
	A_Task_Ptr = &A1;
	//-------------------
}

//=====================================================================
void A2(void) // Spare - not used
//=====================================================================
{

	//-------------------
	A_Task_Ptr = &A3;
	//-------------------
}

//=======================================================================
void A3(void) // Spare - not used
//=======================================================================
{

	//-----------------
	A_Task_Ptr = &A1;
	//-----------------
}



//%%%%%%%%%%%%%%%    B-Tasks:   %%%%%%%%%%%%%%%%%%%%%%%%%
//=====================================================================
void B1(void) // Spare - not used
//=====================================================================
{

	TBcntl = ScopeTimeBase;  // Sample-to-Sample delay

	//-----------------
	B_Task_Ptr = &B2;	
	//-----------------
}

//=====================================================================
void B2(void) // Spare - not used
//=====================================================================
{

	//-----------------
	B_Task_Ptr = &B3;
	//-----------------
}

//=====================================================================
void B3(void) //  Blink LED4 - Host communication status
//=====================================================================
{

  if (CommsOKflg == 0)	// If Host not responding, Blink LED4
  {
	//LED4 blink indicates Slave is waiting for Host comms
	switch(BlinkStatePtr)
	{
	case 0:	// 
		if(VTimer01 > 300)	// 300*4mS = 1.2 sec
		{
			GpioDataRegs.GPBCLEAR.bit.GPIO34=1;	//LED4-ON
			VTimer01 = 0;
			BlinkStatePtr = 1;
		}
		break;

	case 1:	// 
		if(VTimer01 > 25)	// 20*4mS = 0.08 sec
		{
			GpioDataRegs.GPBSET.bit.GPIO34=1;	//LED4-OFF
			VTimer01 = 0;
			BlinkStatePtr = 0;
		}
		break;
	}
  }
	//-----------------
	B_Task_Ptr = &B1;	
	//-----------------
}

//%%%%%%%%%%%%%%%    C-Tasks:   %%%%%%%%%%%%%%%%%%%%%%%%%
//=====================================================================
void C1(void) // 
//=====================================================================
{


	//-----------------
	C_Task_Ptr = &C1;	
	//-----------------
}

//=====================================================================
void C2(void) //  SPARE (not active)
//=====================================================================
{


	//-----------------
	C_Task_Ptr = &C3;	
	//-----------------
}


//=====================================================================
void C3(void) //  SPARE (not active)
//=====================================================================
{


	//-----------------
	C_Task_Ptr = &C1;	
	//-----------------
}




