;*************************************************************************************
;*********************** DSP28 Peripheral Examples *********************************** 
;*************************************************************************************

Thank you for trying C28x Software Collateral. 

This utility contains C281x C/C++ Header Files and Peripheral Examples.

C2000 APPLICATIONS.
Texas Instruments Incorporated 