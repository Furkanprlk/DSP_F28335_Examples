;*************************************************************************************
;*********************** SECTION 1: FFT LIBRARY *********************************** 
;*************************************************************************************
Thank you for trying C28x Software Collateral. 
FFT Library is installed in C:\TIDCS\C28\DSP_TBOX\FFT directory.

Fast Fourier Transforms are an efficient class of algorithms for the digital computation 
of the N-point Fourier transform (DFT). In general, their input sequence are assumed to 
be complex.  In many real applications, the data sequences to be processed are real valued. 
Even though the data is real, complex-valued DFT algorithm can still be used. One simple 
approach creates a complex sequence from the real sequence; that is, real data for the real 
components and zeros for the imaginary components, The complex FFT can then be =applied directly. 


However, this method is not efficient as it consumes 2N memory locations (Real & Imaginary) 
for N point sequence. When input is purely real, their symmetric properties compute DFT very 
efficiently. One such optimized real FFT algorithm for 2N-point real data sequence is packing 
algorithm. The original 2N-point sequence is packed as N-point complex sequence and N -point 
complex FFT is performed on the complex sequence. Finally the resulting N -point complex output 
is unpacked into another N+1 point complex sequence, which corresponds to spectral bin 0 to N 
of 2N-point real input sequence. Spectral bin 0 to N is sufficient, as the remaining bins N+1 
to 2N-1 are complex conjugates of spectral bins N-1 to 1. 

The real FFT requires 2N+2 memory locations to compute the FFT for 2N-point real valued sequence, 
which is highly preferable in contrast to the complex FFT that consumes 4N-locations for 2N-point 
real valued sequence. Moreover using this strategy, the complex FFT size can be reduced by half, 
at the FFT cost function of O(N) operations to pack the input and unpack the output. Hence, 
the real FFT algorithm computes the FFT of a real input sequence almost twice as fast as the 
general FFT algorithm.

This FFT library contains generic FFT module (32-bit implementation) for real/complex FFT.


FFT LIBRARY
|===============|======================================================================|
|  Module Name	| Description						               |
|===============|======================================================================| 
| CFFT32 	| 32-bit complex FFT module		  			       |
|---------------|----------------------------------------------------------------------|
| RFFT32 	| 32-bit Real FFT module					       |
|======================================================================================|
 

DOCUMENTATION:
|===============|======================================================================|
|  DOC		| DIRECTORY LOCATION				        	       |
|===============|======================================================================| 
|  MODULE DOC	| C:\TIDCS\C28\DSP_TBOX\FFT\DOC\FFT_MDL.PDF	  	               |
|======================================================================================|




Version History:
================

version 0.9b dated 8/17/2004
1. Updated the FFT module documentation and used FFT size "N" instead of "2N"
   in real FFT documentation
2. In Real FFT modules, FFT size constant "TWO_N" is replaced with "N"


Version 0.9a dated 12/06/2003 

1. Some the math function had .ref being used in the *.asm, it is changed to .def 
   Because of this bug, compiler was reporting that the function name is not available.

2. Most of the functions did not clear the OVM flag at the end, it is modified.

3. ASP & NASP is been used within functions, we should not disturb the ASP bit.
   It is meant for only interrupt handler. Called function should not change this bit.

4. RFFT_acq function routine required on more call to clear the "acqflag" after the "count"
   reaches "0" and all the data is stored in the "ipcb" buffer. Fixed this bug such that "acqflag" 
   is cleared when the last data is aquired.
